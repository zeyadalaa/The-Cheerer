package the.cheerer.gui;

import java.util.ArrayList;

public abstract class Content {

  
    public abstract ArrayList<String> printData(int feeling);
}
