package the.cheerer.gui;

public class Feelings {

    private int feeling;

    
    public void setFeeling(int feeling)
    {
        this.feeling = feeling;
    }
    public int getFeeling() {
        return feeling;
    }
}
