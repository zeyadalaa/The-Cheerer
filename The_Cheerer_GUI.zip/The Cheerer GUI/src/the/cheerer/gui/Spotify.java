/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package the.cheerer.gui;

import com.wrapper.spotify.SpotifyApi;

import com.wrapper.spotify.exceptions.SpotifyWebApiException;
import com.wrapper.spotify.model_objects.specification.Track;
import com.wrapper.spotify.requests.data.tracks.GetTrackRequest;

import org.apache.http.HttpException;
import java.io.IOException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import  com.wrapper.spotify.model_objects.specification.ExternalUrl;
import  com.wrapper.spotify.model_objects.specification.ExternalUrl.Builder;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author zeyad
 */
// get tracks

public class Spotify {
  //  Authorization authorizer; 
    Music m = new Music();
    Person p = new Person();
    
   
  static final String clientId = "1b9d4c0b62aa43f9b745c595edc9a735";
  static final String clientSecret = "fd27fcc6a45d43dd9c3710435bc3fee0";
  static String id;
    GetTrackRequest getTrackRequest ;
    public Builder builder = new Builder();
    public ExternalUrl ur;
  static final SpotifyApi spotifyApi = new SpotifyApi.Builder()
          .setClientId(clientId)
          .setClientSecret(clientSecret)
         
          .build();

 
  public void setID(String id)
  {
      this.id = id;
  }
  public void getAccessToken(){
      
        try {
            final  ClientCredentialss CC= new ClientCredentialss();
            final SpotifyApi spotifyApi = new SpotifyApi.Builder()
                    .setAccessToken(CC.clientCredentials_Sync())
                    .build();
            getTrackRequest = spotifyApi.getTrack(id)
//          .market(CountryCode.SE)
                    .build();
        } catch (HttpException ex) {
            Logger.getLogger(Spotify.class.getName()).log(Level.SEVERE, null, ex);
        }
      
      
       
  }
  

  public  String getTrack_Sync() {
    try {
      final Track track = getTrackRequest.execute();
      final  ClientCredentialss CC= new ClientCredentialss();
          final SpotifyApi spotifyApi = new SpotifyApi.Builder()
          .setAccessToken(CC.clientCredentials_Sync())
          .build();
          
       try{
      System.out.println("Name: " + track.getName());
       }
       catch (Exception ex)
       {
           System.out.println("" +ex.getMessage());
       }
      return track.getName();
    } catch (IOException  e) {
      System.out.println("Error: " + e.getMessage());
      return e.getMessage();
    }
    catch ( SpotifyWebApiException e)
    {
       return e.getMessage();
    }
    catch(HttpException e)
    {
       return e.getMessage();
    }
  }
  public  String getTrack_Demo() {
    try {
      final Track track = getTrackRequest.execute();
      final  ClientCredentialss CC= new ClientCredentialss();
          final SpotifyApi spotifyApi = new SpotifyApi.Builder()
          .setAccessToken(CC.clientCredentials_Sync())
          .build();
          
       try{
      System.out.println("Name: " + track.getPreviewUrl());
       }
       catch (Exception ex)
       {
           System.out.println("" +ex.getMessage());
       }
      return track.getPreviewUrl();
    } catch (IOException  e) {
      System.out.println("Error: " + e.getMessage());
      return e.getMessage();
    }
    catch ( SpotifyWebApiException e)
    {
       return e.getMessage();
    }
    catch(HttpException e)
    {
       return e.getMessage();
    }
  }

  public  void getTrack_Async() {
    try {
      final Future<Track> trackFuture = getTrackRequest.executeAsync();

      // ...

      final Track track = trackFuture.get();
      System.out.println("Name: " + track.getName());
    } catch (InterruptedException | ExecutionException e) {
      System.out.println("Error: " + e.getCause().getMessage());
    }
  }
  }

